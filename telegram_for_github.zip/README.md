
# Telegram Bot

Этот проект — Telegram-бот, написанный на Python. Он работает с библиотекой `python-telegram-bot` и хранит данные в `users.txt`.

## 📁 Структура

- `main.py` — основной файл бота
- `users.txt` — файл со списком пользователей
- `pyproject.toml` — зависимости проекта (можно заменить на requirements.txt)
- `.gitignore` — игнорируемые файлы
- `.replit` — настройки Replit (необязательно)

## 🚀 Запуск

Убедитесь, что у вас установлен Python 3.10+:

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt  # или pyproject.toml
python main.py
```

## ⚙️ Зависимости

Если используется `pyproject.toml`, установите `uv` или `poetry`:
```bash
pip install uv
uv pip install -r pyproject.toml
```

## 📡 Хостинг 24/7

Для запуска 24/7 можно использовать:
- [Render](https://render.com)
- [Railway](https://railway.app)
- [Fly.io](https://fly.io)
- VPS или сервер

## 🛡️ Безопасность

- Не храните токен бота в открытом виде — используйте `.env` файл или переменные среды.

## 🧑‍💻 Автор

Проект перенесён с Replit для стабильной работы 24/7.
